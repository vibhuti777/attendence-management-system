"# attendance_system" 
install opencv and tkinter in anaconda and run attendance.py and enjoy.
just make a folder named TrainingImageLabel.
